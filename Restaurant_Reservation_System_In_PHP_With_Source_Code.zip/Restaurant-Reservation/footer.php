<!--footer-->
<footer class="footer" id="footer">
 <div class="container"><br>
  <div class="row">
    <div class="col-sm-12 text-center">
      <div class="social-icon">
        <a href="index.php"><i class="fa fa-facebook"></i></a>
        <a href="index.php"><i class="fa fa-twitter"></i></a>
        <a href="index.php"><i class="fa fa-pinterest"></i></a>
        <a href="index.php"><i class="fa fa-rss"></i></a>
      </div>
      <div class="copyright">
        <p class="white"> copyright &copy; <b>Chocolate & Moer</b></p>
        <p><i class="fa fa-phone"></i> +00 (123) 456 7890 &nbsp;<i class="fa fa-envelope-o"></i> info@domain.com</p>
      </div>
    </div>
  </div>
 </div>
</footer>
<!--end of footer-->
</body>
<!---end of body-->
</html>